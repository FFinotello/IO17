.First.lib <- function(libname, pkgname) {
   library.dynam("CNORode2017", pkgname, libname)
}
